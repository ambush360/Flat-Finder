"use client"

import { createContext, useState, useContext } from "react"

const SearchContext = createContext()

export const SearchProvider = ({ children }) => {
  const [searchType, setSearchType] = useState("buy")

  const handleSearchTypeChange = (type) => {
    setSearchType(type)
  }

  return (
    <SearchContext.Provider value={{ searchType, onSearchTypeChange: handleSearchTypeChange }}>
      {children}
    </SearchContext.Provider>
  )
}

export const useSearch = () => useContext(SearchContext)