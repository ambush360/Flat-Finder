"use client";

import { useState, useEffect, useRef } from "react";
import { Send, Smile, Paperclip, Mic } from "lucide-react";
import { Button } from "@/components/ui/button";
import Picker from "emoji-picker-react";
import { v4 as uuidv4 } from "uuid";

/**
 * ChatInterface - local-only chat UI (no API)
 * Props:
 * - currentUser: { _id, name, ... }  // required to mark own messages
 * - selectedChat: optional (kept for compatibility)
 * - isAdmin: optional
 */
export default function ChatInterface({ currentUser }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [file, setFile] = useState(null); // File object for upload preview (optional)
  const [selectedImage, setSelectedImage] = useState(null); // dataURL for preview
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const messagesEndRef = useRef(null);

  // load saved messages from localStorage once
  useEffect(() => {
    try {
      const raw = localStorage.getItem("local_chat_messages");
      if (raw) setMessages(JSON.parse(raw));
    } catch (e) {
      console.warn("Failed to load saved messages", e);
    }
  }, []);

  // persist messages to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem("local_chat_messages", JSON.stringify(messages));
    } catch (e) {
      console.warn("Failed to save messages", e);
    }
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // File input -> keep first file and create preview if image
  const handleFileChange = (e) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const firstFile = fileList[0];
    setFile(firstFile);

    // create data URL for preview if it's an image
    if (firstFile.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (ev) => setSelectedImage(ev.target.result);
      reader.readAsDataURL(firstFile);
    } else {
      setSelectedImage(null);
    }
  };

  const handleEmojiClick = (emojiObject) => {
    setNewMessage((prev) => prev + emojiObject.emoji);
  };

  // Mic start/stop
  const handleMicClick = async () => {
    if (recording) {
      mediaRecorderRef.current?.stop();
      setRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;

      mr.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      mr.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        stream.getTracks().forEach((t) => t.stop());
        audioChunksRef.current = [];
      };

      mr.start();
      setRecording(true);
    } catch (err) {
      console.error("Microphone permission error:", err);
    }
  };

  // Send message locally (text, image/file, or audio)
  const handleSendMessage = (e) => {
    e?.preventDefault?.();

    // nothing to send
    if (!newMessage.trim() && !file && !audioBlob) return;

    const base = {
      _id: uuidv4(),
      senderId: currentUser?._id ?? "local-user",
      createdAt: new Date().toISOString(),
    };

    // If audio is present, add audioURL
    if (audioBlob) {
      const audioUrl = URL.createObjectURL(audioBlob);
      setMessages((prev) => [
        ...prev,
        {
          ...base,
          type: "audio",
          message: "[Voice message]",
          audioUrl,
          audioBlobSize: audioBlob.size,
        },
      ]);
      // clear audio state
      setAudioBlob(null);
      setRecording(false);
      setNewMessage("");
      return;
    }

    // If file (image) is present, attach preview URL (we already created selectedImage)
    if (file) {
      // If image preview available use it, else create object URL
      const fileUrl =
        selectedImage || (file ? URL.createObjectURL(file) : null);

      setMessages((prev) => [
        ...prev,
        {
          ...base,
          type: file.type.startsWith("image/") ? "image" : "file",
          message: newMessage.trim() || (file.type.startsWith("image/") ? "" : file.name),
          fileName: file.name,
          fileUrl,
          fileType: file.type,
          fileSize: file.size,
        },
      ]);

      // cleanup file + preview
      setFile(null);
      setSelectedImage(null);
      setNewMessage("");
      return;
    }

    // Otherwise plain text
    setMessages((prev) => [
      ...prev,
      {
        ...base,
        type: "text",
        message: newMessage.trim(),
      },
    ]);

    setNewMessage("");
  };

  // Delete a message (local only)
  const handleDeleteMessage = (id) => {
    setMessages((prev) => prev.filter((m) => m._id !== id));
  };

  return (
    <div className="bg-white rounded-lg shadow flex flex-col h-[calc(100vh-200px)]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <p className="text-center text-gray-500">No messages yet</p>
        ) : (
          messages.map((msg) => (
            <div
              key={msg._id}
              className={`flex ${msg.senderId === (currentUser?._id ?? "local-user") ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-xs px-4 py-2 rounded-lg ${
                  msg.senderId === (currentUser?._id ?? "local-user") ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-900"
                }`}
              >
                {msg.type === "text" && <p>{msg.message}</p>}

                {msg.type === "image" && (
                  <div className="flex flex-col gap-2">
                    <img src={msg.fileUrl} alt={msg.fileName || "image"} className="w-40 h-auto rounded" />
                    {msg.message && <p>{msg.message}</p>}
                  </div>
                )}

                {msg.type === "file" && (
                  <div className="flex flex-col gap-1">
                    <p className="font-medium">{msg.fileName}</p>
                    <a className="underline text-sm" href={msg.fileUrl} target="_blank" rel="noreferrer">Open file</a>
                    {msg.message && <p>{msg.message}</p>}
                  </div>
                )}

                {msg.type === "audio" && (
                  <div className="flex items-center gap-2">
                    <audio src={msg.audioUrl} controls />
                    <span className="text-xs opacity-80">Voice</span>
                  </div>
                )}

                <p className="text-xs mt-1 opacity-70">
                  {new Date(msg.createdAt).toLocaleTimeString()}
                </p>

                <button
                  onClick={() => handleDeleteMessage(msg._id)}
                  className="text-xs mt-1 underline opacity-60"
                  type="button"
                >
                  Delete
                </button>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSendMessage} className="border-t p-4 flex items-center gap-2">
        <div className="relative">
          <Button type="button" size="icon" variant="ghost" onClick={() => setShowEmojiPicker((s) => !s)}>
            <Smile className="w-5 h-5" />
          </Button>
          {showEmojiPicker && (
            <div className="absolute bottom-12 z-20">
              <Picker onEmojiClick={handleEmojiClick} />
            </div>
          )}
        </div>

        <label htmlFor="file-upload" className="cursor-pointer">
          <Paperclip className="w-5 h-5" />
        </label>
        <input id="file-upload" type="file" className="hidden" onChange={handleFileChange} />

        <Button type="button" size="icon" variant="ghost" onClick={handleMicClick}>
          <Mic className={`w-5 h-5 ${recording ? "text-red-500" : ""}`} />
        </Button>

        {/* preview selected image */}
        {selectedImage && (
          <div className="relative">
            <img src={selectedImage} alt="Selected" className="w-16 h-16 object-cover rounded-lg" />
            <button
              type="button"
              className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center"
              onClick={() => {
                setSelectedImage(null);
                setFile(null);
              }}
            >
              X
            </button>
          </div>
        )}

        {/* preview recorded audio */}
        {audioBlob && (
          <div className="flex items-center gap-2">
            <audio src={URL.createObjectURL(audioBlob)} controls />
            <button
              type="button"
              className="bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center"
              onClick={() => setAudioBlob(null)}
            >
              X
            </button>
          </div>
        )}

        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type a message..."
          className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <Button type="submit" size="icon">
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
}
