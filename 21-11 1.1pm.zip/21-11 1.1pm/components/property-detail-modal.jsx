"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { X, Share2, Bed, Bath, Maximize, MapPin, Calendar, Home, ChevronLeft, ChevronRight } from "lucide-react"

export default function PropertyDetailModal({ property, isOpen, onClose, currentUser }) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const router = useRouter()

  if (!isOpen) return null

  const nextImage = () => {
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % property.images.length)
    }
  }

  const prevImage = () => {
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length)
    }
  }

  const handleContactOwner = () => {
    if (!currentUser) {
      alert("Please sign in to contact the owner.")
      return
    }
    localStorage.setItem("contactOwner", JSON.stringify({
      _id: property.userId,
      name: "Owner",
    }))
    router.push("/messages")
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between z-10">
          <h2 className="text-2xl font-bold text-gray-900 font-heading">{property.title}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Image Slider */}
        <div className="relative h-96 bg-gray-100">
          <img
            src={(property.images && property.images.length > 0) ? property.images[currentImageIndex] : "/placeholder.svg"}
            alt={property.title}
            className="w-full h-full object-cover"
          />

          {/* Image Navigation */}
          {property.images?.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                aria-label="Previous image"
              >
                <ChevronLeft className="w-6 h-6 text-gray-900" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                aria-label="Next image"
              >
                <ChevronRight className="w-6 h-6 text-gray-900" />
              </button>

              {/* Image Counter */}
              <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                {currentImageIndex + 1} / {property.images?.length}
              </div>
            </>
          )}

          {/* Action Buttons */}
          <div className="absolute top-4 right-4 flex gap-2">
            <button
              className="bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
              aria-label="Share property"
            >
              <Share2 className="w-5 h-5 text-gray-900" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Price and Location */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="text-3xl font-bold text-blue-600 mb-2">{property.price}</div>
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-5 h-5" />
                <span>{property.location}</span>
              </div>
            </div>
          </div>

          {/* Property Features */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-2">
                <Bed className="w-5 h-5 text-blue-600" />
                <div>
                  <div className="text-sm text-gray-500">Bedrooms</div>
                  <div className="font-semibold text-gray-900">{property.bedrooms}</div>
                </div>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-2">
                <Bath className="w-5 h-5 text-blue-600" />
                <div>
                  <div className="text-sm text-gray-500">Bathrooms</div>
                  <div className="font-semibold text-gray-900">{property.bathrooms}</div>
                </div>
              </div>
            )}
            <div className="flex items-center gap-2">
              <Maximize className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-sm text-gray-500">Size</div>
                <div className="font-semibold text-gray-900">{property.size}</div>
              </div>
            </div>
            {property.propertyType && (
              <div className="flex items-center gap-2">
                <Home className="w-5 h-5 text-blue-600" />
                <div>
                  <div className="text-sm text-gray-500">Type</div>
                  <div className="font-semibold text-gray-900">{property.propertyType}</div>
                </div>
              </div>
            )}
          </div>

          {/* Description */}
          <div className="mb-6">
            <h3 className="text-xl font-bold text-gray-900 mb-3 font-heading">Description</h3>
            <p className="text-gray-700 leading-relaxed">
              {property.description ||
                "This beautiful property offers modern living spaces with excellent amenities. Located in a prime area with easy access to schools, shopping centers, and transportation. Perfect for families looking for comfort and convenience in the heart of the city."}
            </p>
          </div>

          {/* Amenities */}
          {property.amenities && property.amenities.length > 0 && (
            <div className="mb-6">
              <h3 className="text-xl font-bold text-gray-900 mb-3 font-heading">Amenities</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {property.amenities.map((amenity, index) => (
                  <div key={index} className="flex items-center gap-2 text-gray-700">
                    <div className="w-2 h-2 bg-blue-600 rounded-full" />
                    <span>{amenity}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Additional Info */}
          {property.yearBuilt && (
            <div className="flex items-center gap-2 text-gray-600 mb-6">
              <Calendar className="w-5 h-5" />
              <span>Built in {property.yearBuilt}</span>
            </div>
          )}

          {/* Contact Button */}
          <button
            onClick={handleContactOwner}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-lg transition-colors"
          >
            Contact Owner
          </button>
        </div>
      </div>
    </div>
  )
}
