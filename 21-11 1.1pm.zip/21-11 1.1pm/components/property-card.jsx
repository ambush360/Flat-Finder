"use client"

import { useState, useEffect } from "react"
import { Share2, Bed, Bath, Maximize, ChevronLeft, ChevronRight, Clock } from "lucide-react"
import PropertyDetailModal from "./property-detail-modal"
import ShareModal from "./share-modal"

export default function PropertyCard({ property, user }) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [isShareModalOpen, setIsShareModalOpen] = useState(false)

  const nextImage = (e) => {
    e.preventDefault()
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % property.images.length)
    }
  }

  const prevImage = (e) => {
    e.preventDefault()
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length)
    }
  }

  const handleImageClick = () => {
    setIsModalOpen(true)
  }


  const handleShareClick = async (e) => {
    e.preventDefault()
    setIsShareModalOpen(true)
  }

  const formatDate = (dateString) => {
    if (!dateString) return ""
    const date = new Date(dateString)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    const isToday = date.toDateString() === today.toDateString()
    const isYesterday = date.toDateString() === yesterday.toDateString()

    if (isToday) {
      return `Today at ${date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`
    } else if (isYesterday) {
      return `Yesterday at ${date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`
    } else {
      return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
    }
  }

  const formatPrice = (price, userType) => {
    const numericPrice = Number(price.toString().replace(/,/g, ''));
    if (isNaN(numericPrice)) {
      return price;
    }
  
    const formattedPrice = numericPrice.toLocaleString('en-IN');
  
    if (userType === 'seller') {
      return `৳ ${formattedPrice} Tk`;
    } else if (userType === 'owner') {
      return `৳ ${formattedPrice} Tk/Monthly`;
    }
    return `৳ ${formattedPrice}`;
  };
  return (
    <>
      <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow overflow-hidden group">
        {/* Image Slider */}
        <div className="relative h-48 overflow-hidden cursor-pointer" onClick={handleImageClick}>
          <img
            src={(property.images && property.images.length > 0) ? property.images[currentImageIndex] : "/placeholder.svg"}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />

          {/* Image Navigation */}
          {property.images?.length > 1 && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Previous image"
              >
                <ChevronLeft className="w-5 h-5 text-(--color-foreground)" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Next image"
              >
                <ChevronRight className="w-5 h-5 text-(--color-foreground)" />
              </button>

              {/* Image Indicators */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-1">
                {property.images.map((_, index) => (
                  <div
                    key={index}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentImageIndex ? "bg-white w-6" : "bg-white/50"
                    }`}
                  />
                ))}
              </div>
            </>
          )}

          {/* Action Buttons */}
          <div className="absolute top-4 right-4 flex gap-2">
            <button
              onClick={handleShareClick}
              className="bg-white/90 hover:bg-white p-2 rounded-full shadow-lg transition-colors"
              aria-label="Share property"
            >
              <Share2 className="w-5 h-5 text-(--color-foreground)" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-5">
          <h3 className="text-xl font-bold text-(--color-foreground) mb-2 font-heading">{property.title}</h3>
          <p className="text-black text-sm mb-3 flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
              />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            {property.location}
          </p>

          <div className="flex items-center justify-between mb-4">
          <span className="text-2xl font-bold text-(--color-primary)">
          {formatPrice(property.price, property.userType)}
        </span>
          </div>

          {/* Features */}
          <div className="flex items-center gap-4 text-sm text-black border-t border-(--color-border) pt-4">
            {property.bedrooms > 0 && (
              <div className="flex items-center gap-1">
                <Bed className="w-4 h-4" />
                <span>{property.bedrooms} Bed</span>
              </div>
            )}
            {property.bathrooms > 0 && (
              <div className="flex items-center gap-1">
                <Bath className="w-4 h-4" />
                <span>{property.bathrooms} Bath</span>
              </div>
            )}
            <div className="flex items-center gap-1">
              <Maximize className="w-4 h-4" />
              <span>{property.size}</span>
            </div>
          </div>

          {property.createdAt && (
            <div className="flex items-center gap-1 text-xs text-gray-500 mt-3 pt-3 border-t border-(--color-border)">
              <Clock className="w-3 h-3" />
              <span>Posted: {formatDate(property.createdAt)}</span>
            </div>
          )}
        </div>
      </div>

      {/* Property Detail Modal */}
      <PropertyDetailModal property={property} isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} currentUser={user} />

      {/* Share Modal */}
      <ShareModal property={property} isOpen={isShareModalOpen} onClose={() => setIsShareModalOpen(false)} />
    </>
  )
}
