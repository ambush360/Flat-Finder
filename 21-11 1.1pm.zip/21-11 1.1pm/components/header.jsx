"use client"

import { useState, useEffect } from "react"
import { Home, Menu, User, Heart, MessageCircle, LogOut, PlusCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import AuthModal from "@/components/auth-modal"
import AddPropertyModal from "@/components/add-property-modal"
import AddRentModal from "@/components/add-rent-modal"
import Link from "next/link"
import { useSearch } from "@/context/SearchContext"

export default function Header() {
  const { onSearchTypeChange } = useSearch()
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const [isAddPropertyModalOpen, setIsAddPropertyModalOpen] = useState(false)
  const [isAddRentModalOpen, setIsAddRentModalOpen] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [user, setUser] = useState(null)

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        setUser(JSON.parse(storedUser))
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error)
      // If parsing fails, remove the corrupted item
      localStorage.removeItem("user")
      setUser(null)
    }
  }, [])

  const handleLogout = () => {
    localStorage.removeItem("user")
    setUser(null)
    window.location.reload()
  }
 
  return (
    <>
      <header className="sticky top-0 z-50 bg-white border-b border-(--color-border) shadow-sm">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Logo and Title */}
            <div className="flex items-center gap-2 flex-shrink-0">
              <div className="w-10 h-10 bg-(--color-primary) rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <span className="text-base md:text-lg font-bold text-(--color-foreground) font-heading whitespace-nowrap">
                Flat Buy Sell & Rent
              </span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              <Link
                href="/"
                className="text-(--color-foreground) hover:text-(--color-primary) font-medium transition-colors"
              >
                Home
              </Link>
              <button
                onClick={() => onSearchTypeChange("buy")}
                className="text-(--color-foreground) hover:text-(--color-primary) font-medium transition-colors"
              >
                Buy
              </button>
              <button
                onClick={() => onSearchTypeChange("rent")}
                className="text-(--color-foreground) hover:text-(--color-primary) font-medium transition-colors"
              >
                Rent
              </button>
              <Link
                href="/messages"
                className="text-(--color-foreground) hover:text-(--color-primary) font-medium transition-colors flex items-center gap-1"
              >
                <MessageCircle className="w-4 h-4" />
                Message
              </Link>
            </nav>

            {/* Right Side Actions */}
            <div className="flex items-center gap-2">
              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="lg:hidden p-2 hover:bg-(--color-surface) rounded-lg transition-colors"
                aria-label="Toggle menu"
              >
                <Menu className="w-6 h-6 text-(--color-foreground)" />
              </button>

              {/* Profile Button */}
              {user ? (
                <div className="flex items-center gap-2">
                  {user.userType === "seller" && (
                    <Button
                      onClick={() => setIsAddPropertyModalOpen(true)}
                      className="hidden sm:flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span className="text-sm font-medium">Add Property</span>
                    </Button>
                  )}
                  {user.userType === "owner" && (
                    <Button
                      onClick={() => setIsAddRentModalOpen(true)}
                      className="hidden sm:flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span className="text-sm font-medium">Add Rent</span>
                    </Button>
                  )}
                  <span className="font-medium text-sm text-gray-700">
                    {user.name.charAt(0).toUpperCase() + user.name.slice(1)}
                  </span>
                  <Button
                    onClick={handleLogout}
                    className="w-10 h-10 rounded-full bg-red-500 hover:bg-red-600 p-0 flex items-center justify-center flex-shrink-0"
                    aria-label="Sign out"
                  >
                    <LogOut className="w-5 h-5 text-white" />
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={() => setIsAuthModalOpen(true)}
                  className="w-10 h-10 rounded-full bg-(--color-primary) hover:bg-(--color-primary-hover) p-0 flex items-center justify-center flex-shrink-0"
                  aria-label="Sign in"
                >
                  <User className="w-5 h-5 text-white" />
                </Button>
              )}
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="lg:hidden py-4 border-t border-(--color-border)">
              <nav className="flex flex-col gap-2">
                <Link
                  href="/"
                  className="px-4 py-2 text-(--color-foreground) hover:bg-(--color-surface) rounded-lg font-medium transition-colors"
                >
                  Home
                </Link>
                <button
                  onClick={() => {
                    onSearchTypeChange("buy")
                    setIsMobileMenuOpen(false)
                  }}
                  className="px-4 py-2 text-(--color-foreground) hover:bg-(--color-surface) rounded-lg font-medium transition-colors text-left"
                >
                  Buy
                </button>
                <button
                  onClick={() => {
                    onSearchTypeChange("rent")
                    setIsMobileMenuOpen(false)
                  }}
                  className="px-4 py-2 text-(--color-foreground) hover:bg-(--color-surface) rounded-lg font-medium transition-colors text-left"
                >
                  Rent
                </button>
                <Link
                  href="/messages"
                  className="px-4 py-2 text-(--color-foreground) hover:bg-(--color-surface) rounded-lg font-medium transition-colors flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Message
                </Link>
              </nav>
            </div>
          )}
        </div>
      </header>

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
      {user && (
        <AddPropertyModal
          isOpen={isAddPropertyModalOpen}
          onClose={() => setIsAddPropertyModalOpen(false)}
          userType={user.userType}
          userId={user.id}
        />
      )}
      {user && (
        <AddRentModal
          isOpen={isAddRentModalOpen}
          onClose={() => setIsAddRentModalOpen(false)}
          userId={user.id}
        />
      )}
    </>
  )
}
