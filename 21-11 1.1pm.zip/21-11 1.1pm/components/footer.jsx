"use client"

import { Heart, MessageCircle, Info } from "lucide-react"
import Link from "next/link"

export default function Footer() {
  return (
    <>
      {/* Desktop Footer */}
      <footer className="hidden md:block bg-(--color-foreground) text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">

            {/* Brand */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-(--color-primary) rounded-lg flex items-center justify-center overflow-hidden">
                  <img
                    src="/uploads/house.png"
                    alt="Flat Buy Sell & Rent logo"
                    className="w-8 h-8 object-contain"
                  />
                </div>
                <span className="text-lg font-bold font-heading">
                  Flat Buy Sell & Rent
                </span>
              </div>
              <p className="text-gray-400 text-sm">
                Made for Bangladesh Real Estate Market
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="font-semibold mb-4 font-heading">Quick Links</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><Link href="/buy-property" className="hover:text-white transition-colors">Buy Property</Link></li>
                <li><Link href="/sell-property" className="hover:text-white transition-colors">Sell Property</Link></li>
                <li><Link href="/rent-property" className="hover:text-white transition-colors">Rent Property</Link></li>
                <li><Link href="/about-us" className="hover:text-white transition-colors">About Us</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="font-semibold mb-4 font-heading">Contact</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>Phone: +880 1522105645</li>
                <li>Email: shuhanbubt@gmail.com</li>
                <li>Address: Dhaka, Bangladesh</li>
              </ul>
            </div>

            {/* Social Media */}
            <div>
              <h3 className="font-semibold mb-4 font-heading">Follow Us</h3>
              <div className="flex gap-3">

                {/* Facebook */}
                <a
                  href="https://www.facebook.com/shs.shuhan"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook"
                  className="w-10 h-10 bg-white/10 hover:bg-(--color-primary) rounded-lg flex items-center justify-center transition-colors"
                >
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M22.675 0h-21.35C.597 0 0 .597 0 1.326v21.349C0 
                    23.403.597 24 1.326 24H12.82v-9.294H9.692v-3.622h3.128V8.413c0-3.1 
                    1.894-4.788 4.659-4.788 1.325 0 2.464.099 
                    2.795.143v3.24h-1.918c-1.504 0-1.797.715-1.797 
                    1.764v2.316h3.587l-.467 3.622h-3.12V24h6.116C23.403 24 24 
                    23.403 24 22.675V1.326C24 .597 23.403 0 22.675 0z"/>
                  </svg>
                </a>

                {/* Twitter / X */}
                <a
                  href="https://x.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="X (Twitter)"
                  className="w-10 h-10 bg-white/10 hover:bg-(--color-primary) rounded-lg flex items-center justify-center transition-colors"
                >
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M18.244 2H21.5l-7.168 8.21L23.5 22h-6.77l-5.02-6.59L6.02 
                    22H2.5l7.64-8.75L1.5 2h6.91l4.33 5.77L18.244 2zm-1.18 
                    17.53h1.9L7.06 4.39H5.04l12.02 15.14z"/>
                  </svg>
                </a>

                {/* Instagram */}
                <a
                  href="https://www.instagram.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Instagram"
                  className="w-10 h-10 bg-white/10 hover:bg-(--color-primary) rounded-lg flex items-center justify-center transition-colors"
                >
                  <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M7 2C4.243 2 2 4.243 2 7v10c0 2.757 2.243 5 
                    5 5h10c2.757 0 5-2.243 
                    5-5V7c0-2.757-2.243-5-5-5H7zm10 
                    2c1.654 0 3 1.346 3 3v10c0 1.654-1.346 
                    3-3 3H7c-1.654 0-3-1.346-3-3V7c0-1.654 
                    1.346-3 3-3h10zm-5 3a5 5 0 100 10 
                    5 5 0 000-10zm0 2a3 3 0 110 6 3 
                    3 0 010-6zm4.5-3a1.5 1.5 0 100 3 
                    1.5 1.5 0 000-3z"/>
                  </svg>
                </a>

              </div>
            </div>

          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2025 Flat Buy Sell & Rent. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-(--color-border) shadow-lg z-50">
        <div className="grid grid-cols-4 h-16">
          <Link href="/" className="flex flex-col items-center justify-center gap-1 text-(--color-primary)">
            <img src="/uploads/house.png" alt="home" className="w-6 h-6 object-contain" />
            <span className="text-xs font-medium">Home</span>
          </Link>
          <a href="#favorites" className="flex flex-col items-center justify-center gap-1 text-(--color-muted) hover:text-(--color-primary)">
            <Heart className="w-6 h-6" />
            <span className="text-xs font-medium">Favorite</span>
          </a>
          <a href="#messages" className="flex flex-col items-center justify-center gap-1 text-(--color-muted) hover:text-(--color-primary)">
            <MessageCircle className="w-6 h-6" />
            <span className="text-xs font-medium">Message</span>
          </a>
          <Link href="/about-us" className="flex flex-col items-center justify-center gap-1 text-(--color-muted) hover:text-(--color-primary)">
            <Info className="w-6 h-6" />
            <span className="text-xs font-medium">About</span>
          </Link>
        </div>
      </nav>
    </>
  )
}
