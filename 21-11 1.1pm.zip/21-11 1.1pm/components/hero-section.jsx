"use client"

import { useState } from "react"
import { Search, MapPin, Home, DollarSign, Maximize } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useSearch } from "@/context/SearchContext"

export default function HeroSection({ onSearch }) {
  const { searchType, onSearchTypeChange } = useSearch()
  const [location, setLocation] = useState("")
  const [propertyType, setPropertyType] = useState("All Types")
  const [priceRange, setPriceRange] = useState("Any Price")
  const [size, setSize] = useState("Any Size")

  const handleSearch = () => {
    onSearch({
      type: searchType,
      location,
      propertyType,
      priceRange,
      size,
    })
  }

  return (
    <section className="relative bg-gradient-to-br from-(--color-surface) to-white py-16 md:py-24">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <img
          src="/modern-minimalist-bangladesh-apartment-interior-wi.jpg"
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-8">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-(--color-foreground) mb-4 font-heading text-balance">
            Properties Made Simple in Bangladesh
          </h1>
          <p className="text-lg md:text-xl text-(--color-primary) font-semibold text-balance">
            Find your dream home in Dhaka, Chittagong, Sylhet, and beyond
          </p>
        </div>

        {/* Search Card */}
        <div className="max-w-5xl mx-auto bg-white rounded-2xl shadow-xl p-6 md:p-8">
          {/* Toggle Buttons */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => onSearchTypeChange("buy")}
              className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-all ${
                searchType === "buy"
                  ? "bg-(--color-primary) text-white shadow-lg"
                  : "bg-(--color-surface) text-(--color-foreground) hover:bg-(--color-surface-hover)"
              }`}
            >
              Buy
            </button>
            <button
              onClick={() => onSearchTypeChange("rent")}
              className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-all ${
                searchType === "rent"
                  ? "bg-(--color-primary) text-white shadow-lg"
                  : "bg-(--color-surface) text-(--color-foreground) hover:bg-(--color-surface-hover)"
              }`}
            >
              Rent
            </button>
          </div>

          {/* Search Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Location */}
            <div className="relative">
              <label className="block text-sm font-medium text-(--color-foreground) mb-2">Location</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                <Input
                  type="text"
                  placeholder="Mirpur, Gulshan, Dhanmondi..."
                  className="pl-10"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
            </div>

            {/* Property Type */}
            <div>
              <label className="block text-sm font-medium text-(--color-foreground) mb-2">Property Type</label>
              <div className="relative">
                <Home className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted) pointer-events-none z-10" />
                <select
                  className="w-full h-10 pl-10 pr-4 border border-(--color-border) rounded-lg bg-white text-(--color-foreground) focus:outline-none focus:ring-2 focus:ring-(--color-primary)"
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                >
                  <option>All Types</option>
                  <option>Apartment</option>
                  <option>House</option>
                  <option>Duplex</option>
                  <option>Penthouse</option>
                </select>
              </div>
            </div>

            {/* Price */}
            <div>
              <label className="block text-sm font-medium text-(--color-foreground) mb-2">
                {searchType === "buy" ? "Price (BDT)" : "Monthly Rent (BDT)"}
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted) pointer-events-none z-10" />
                <select
                  className="w-full h-10 pl-10 pr-4 border border-(--color-border) rounded-lg bg-white text-(--color-foreground) focus:outline-none focus:ring-2 focus:ring-(--color-primary)"
                  value={priceRange}
                  onChange={(e) => setPriceRange(e.target.value)}
                >
                  {searchType === "buy" ? (
                    <>
                      <option>Any Price</option>
                      <option>৳ 10L - 25L</option>
                      <option>৳ 25L - 50L</option>
                      <option>৳ 50L - 1Cr</option>
                      <option>৳ 1Cr+</option>
                    </>
                  ) : (
                    <>
                      <option>Any Rent</option>
                      <option>৳ 10,000 - 15,000</option>
                      <option>৳ 15,000 - 20,000</option>
                      <option>৳ 20,000 - 30,000</option>
                      <option>৳ 30,000 - 40,000</option>
                      <option>৳ 40,000 - 50,000</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            {/* Size */}
            <div>
              <label className="block text-sm font-medium text-(--color-foreground) mb-2">Size (sqft)</label>
              <div className="relative">
                <Maximize className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted) pointer-events-none z-10" />
                <select
                  className="w-full h-10 pl-10 pr-4 border border-(--color-border) rounded-lg bg-white text-(--color-foreground) focus:outline-none focus:ring-2 focus:ring-(--color-primary)"
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                >
                  <option>Any Size</option>
                  <option>500 - 1000</option>
                  <option>1000 - 1500</option>
                  <option>1500 - 2000</option>
                  <option>2000+</option>
                </select>
              </div>
            </div>
          </div>

          {/* Search Button */}
          <Button
            className="w-full mt-6 bg-(--color-primary) hover:bg-(--color-primary-hover) text-white font-semibold py-4 text-lg flex items-center justify-center gap-2"
            onClick={handleSearch}
          >
            <Search className="w-5 h-5" />
            Search Properties
          </Button>
        </div>
      </div>
    </section>
  )
}
