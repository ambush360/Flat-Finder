"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import PropertyCard from "@/components/property-card"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { useSearch } from "@/context/SearchContext"

const defaultProperties = {
  buy: [
    {
      id: 1,
      userId: "user_1",
      title: "3 Bedroom Luxury Apartment",
      location: "Gulshan 2, Dhaka",
      price: "৳ 85,00,000",
      size: "1,850 sqft",
      bedrooms: 3,
      bathrooms: 3,
      image: "/modern-luxury-apartment-gulshan-dhaka-bangladesh-i.jpg",
      images: [
        "/modern-luxury-apartment-gulshan-dhaka-bangladesh-i.jpg",
        "/luxury-apartment-bedroom-dhaka.jpg",
        "/modern-kitchen-apartment-bangladesh.jpg",
      ],
      description:
        "Experience luxury living in the heart of Gulshan 2. This stunning 3-bedroom apartment features modern architecture, spacious rooms, and premium finishes throughout. Located in one of Dhaka's most prestigious neighborhoods, you'll enjoy easy access to international schools, embassies, shopping centers, and fine dining restaurants. The apartment comes with a modern kitchen, elegant bathrooms, and large windows offering plenty of natural light.",
      propertyType: "Apartment",
      yearBuilt: "2022",
      amenities: [
        "24/7 Security",
        "Elevator",
        "Parking Space",
        "Generator Backup",
        "Rooftop Garden",
        "Gym",
        "Community Hall",
      ],
    },
    {
      id: 2,
      userId: "user_2",
      title: "4 Bedroom Duplex House",
      location: "Banani, Dhaka",
      price: "৳ 1,20,00,000",
      size: "2,500 sqft",
      bedrooms: 4,
      bathrooms: 4,
      image: "/modern-duplex-house-banani-dhaka-bangladesh-exteri.jpg",
      images: ["/modern-duplex-house-banani-dhaka-bangladesh-exteri.jpg", "/duplex-house-living-room-dhaka.jpg"],
      description:
        "Spacious duplex house in prime Banani location. This beautiful property offers 4 bedrooms with attached bathrooms, a large living and dining area, modern kitchen, and a private rooftop terrace. Perfect for families seeking comfort and convenience in one of Dhaka's most sought-after residential areas. Close to Banani Lake, restaurants, shopping malls, and international schools.",
      propertyType: "Duplex",
      yearBuilt: "2021",
      amenities: ["Private Parking", "Rooftop Terrace", "Security System", "Generator", "Servant Quarter", "Balcony"],
    },
    {
      id: 3,
      userId: "user_3",
      title: "2 Bedroom Modern Flat",
      location: "Dhanmondi, Dhaka",
      price: "৳ 55,00,000",
      size: "1,200 sqft",
      bedrooms: 2,
      bathrooms: 2,
      image: "/modern-apartment-dhanmondi-dhaka-bangladesh.jpg",
      images: ["/modern-apartment-dhanmondi-dhaka-bangladesh.jpg"],
      description:
        "Cozy 2-bedroom flat in the cultural heart of Dhaka. Located in peaceful Dhanmondi, this apartment offers a perfect blend of modern amenities and traditional charm. Walking distance to Dhanmondi Lake, Rabindra Sarobar, restaurants, and shopping areas. Ideal for small families or young professionals.",
      propertyType: "Flat",
      yearBuilt: "2020",
      amenities: ["Lift Service", "Security Guard", "Parking", "Gas Connection", "Water Supply"],
    },
    {
      id: 4,
      userId: "user_4",
      title: "Penthouse with City View",
      location: "Uttara, Dhaka",
      price: "৳ 1,50,00,000",
      size: "3,200 sqft",
      bedrooms: 4,
      bathrooms: 5,
      image: "/penthouse-apartment-uttara-dhaka-city-view.jpg",
      images: ["/penthouse-apartment-uttara-dhaka-city-view.jpg"],
      description:
        "Luxurious penthouse with breathtaking city views. This exclusive property features floor-to-ceiling windows, a private terrace, premium imported fixtures, and state-of-the-art amenities. Located in Uttara's most prestigious building with world-class facilities. Perfect for those who appreciate the finer things in life.",
      propertyType: "Penthouse",
      yearBuilt: "2023",
      amenities: [
        "Swimming Pool",
        "Gym",
        "Sauna",
        "Private Elevator",
        "Concierge Service",
        "Smart Home System",
        "Jacuzzi",
        "BBQ Area",
      ],
    },
    {
      id: 5,
      userId: "user_5",
      title: "3 Bedroom Apartment",
      location: "Mirpur DOHS, Dhaka",
      price: "৳ 65,00,000",
      size: "1,600 sqft",
      bedrooms: 3,
      bathrooms: 3,
      image: "/apartment-mirpur-dohs-dhaka-bangladesh.jpg",
      images: ["/apartment-mirpur-dohs-dhaka-bangladesh.jpg"],
      description:
        "Well-maintained apartment in the secure and family-friendly Mirpur DOHS community. Features spacious rooms, modern kitchen, and excellent ventilation. The area offers a peaceful environment with parks, playgrounds, schools, and shopping facilities nearby. Great for families looking for a safe and comfortable living space.",
      propertyType: "Apartment",
      yearBuilt: "2019",
      amenities: ["Community Security", "Playground", "Mosque", "Shopping Complex", "Parking", "Generator"],
    },
    {
      id: 6,
      userId: "user_6",
      title: "Luxury Villa",
      location: "Bashundhara, Dhaka",
      price: "৳ 2,00,00,000",
      size: "4,000 sqft",
      bedrooms: 5,
      bathrooms: 6,
      image: "/luxury-villa-bashundhara-dhaka-bangladesh.jpg",
      images: ["/luxury-villa-bashundhara-dhaka-bangladesh.jpg"],
      description:
        "Magnificent villa in Bashundhara Residential Area. This architectural masterpiece features 5 spacious bedrooms, a grand living area, formal dining room, modern kitchen, private garden, and swimming pool. Built with premium materials and designed for luxury living. Located in a gated community with 24/7 security.",
      propertyType: "Villa",
      yearBuilt: "2022",
      amenities: [
        "Private Pool",
        "Garden",
        "Home Theater",
        "Wine Cellar",
        "Maid's Room",
        "Driver's Room",
        "CCTV",
        "Smart Home",
      ],
    },
    {
      id: 13,
      userId: "user_13",
      title: "Commercial Space",
      location: "Motijheel, Dhaka",
      price: "৳ 1,80,00,000",
      size: "3,500 sqft",
      bedrooms: 0,
      bathrooms: 2,
      image: "/commercial-office-space-motijheel-dhaka.jpg",
      images: ["/commercial-office-space-motijheel-dhaka.jpg"],
      description:
        "Prime commercial space in Motijheel, Dhaka's business district. Ideal for corporate offices, banks, or commercial establishments. Features open floor plan, modern facilities, and excellent visibility. Located near government offices, banks, and major business centers.",
      propertyType: "Commercial",
      yearBuilt: "2018",
      amenities: ["Elevator", "Parking", "Generator", "Security", "Fire Safety System", "Central AC"],
    },
    {
      id: 14,
      userId: "user_14",
      title: "Land Plot",
      location: "Purbachal, Dhaka",
      price: "৳ 45,00,000",
      size: "5 Katha",
      bedrooms: 0,
      bathrooms: 0,
      image: "/residential-land-plot-purbachal-dhaka.jpg",
      images: ["/residential-land-plot-purbachal-dhaka.jpg"],
      description:
        "Excellent residential plot in Purbachal New Town, one of Dhaka's fastest-growing planned communities. Clear title, ready for construction. Located in a well-developed sector with roads, utilities, and infrastructure in place. Great investment opportunity.",
      propertyType: "Land",
      amenities: ["Clear Title", "Road Access", "Electricity Connection", "Gas Line Available", "Planned Community"],
    },
    {
      id: 15,
      userId: "user_15",
      title: "Corner Plot House",
      location: "Uttara Sector 7, Dhaka",
      price: "৳ 95,00,000",
      size: "2,200 sqft",
      bedrooms: 3,
      bathrooms: 3,
      image: "/corner-house-uttara-sector-7-dhaka.jpg",
      images: ["/corner-house-uttara-sector-7-dhaka.jpg"],
      description:
        "Well-built corner plot house in Uttara Sector 7. Features 3 bedrooms, modern kitchen, spacious living areas, and a small garden. Corner location provides extra space and better ventilation. Located in a family-friendly neighborhood with schools, mosques, and markets nearby.",
      propertyType: "House",
      yearBuilt: "2017",
      amenities: ["Corner Plot", "Garden", "Parking", "Security Gate", "Rooftop Access"],
    },
  ],
  rent: [
    {
      id: 7,
      userId: "user_7",
      title: "2 Bedroom Furnished Flat",
      location: "Mohammadpur, Dhaka",
      price: "৳ 25,000/month",
      size: "1,100 sqft",
      bedrooms: 2,
      bathrooms: 2,
      image: "/furnished-apartment-mohammadpur-dhaka-bangladesh.jpg",
      images: ["/furnished-apartment-mohammadpur-dhaka-bangladesh.jpg"],
      description:
        "Fully furnished 2-bedroom flat ready for immediate move-in. Includes all necessary furniture, kitchen appliances, and utilities. Located in a well-connected area with easy access to public transport, markets, and restaurants. Perfect for working professionals or small families.",
      propertyType: "Flat",
      amenities: ["Furnished", "Wi-Fi Ready", "Parking", "Security", "Generator Backup"],
    },
    {
      id: 8,
      userId: "user_8",
      title: "3 Bedroom Family Apartment",
      location: "Lalmatia, Dhaka",
      price: "৳ 35,000/month",
      size: "1,500 sqft",
      bedrooms: 3,
      bathrooms: 2,
      image: "/family-apartment-lalmatia-dhaka-bangladesh.jpg",
      images: ["/family-apartment-lalmatia-dhaka-bangladesh.jpg"],
      description:
        "Spacious family apartment in quiet Lalmatia neighborhood. Features large bedrooms, airy living spaces, and a well-equipped kitchen. The building has reliable utilities and friendly neighbors. Close to schools, hospitals, and shopping areas. Ideal for families seeking a peaceful residential environment.",
      propertyType: "Apartment",
      amenities: ["Lift", "Parking", "Gas Line", "Water Supply", "Security Guard"],
    },
    {
      id: 9,
      userId: "user_9",
      title: "Studio Apartment",
      location: "Khilgaon, Dhaka",
      price: "৳ 15,000/month",
      size: "650 sqft",
      bedrooms: 1,
      bathrooms: 1,
      image: "/studio-apartment-khilgaon-dhaka-bangladesh.jpg",
      images: ["/studio-apartment-khilgaon-dhaka-bangladesh.jpg"],
      description:
        "Compact and efficient studio apartment perfect for single professionals or students. Features an open-plan living space, kitchenette, and modern bathroom. Located near public transport and local amenities. Affordable and convenient living in the city.",
      propertyType: "Studio",
      amenities: ["Furnished Option", "Wi-Fi", "Security", "Water Supply"],
    },
    {
      id: 10,
      userId: "user_10",
      title: "4 Bedroom Duplex",
      location: "Baridhara, Dhaka",
      price: "৳ 80,000/month",
      size: "2,800 sqft",
      bedrooms: 4,
      bathrooms: 4,
      image: "/duplex-apartment-baridhara-dhaka-bangladesh.jpg",
      images: ["/duplex-apartment-baridhara-dhaka-bangladesh.jpg"],
      description:
        "Premium duplex apartment in exclusive Baridhara diplomatic zone. Features elegant interiors, spacious rooms, modern amenities, and a private terrace. Located in a secure compound with international standard facilities. Perfect for expatriates and high-profile families.",
      propertyType: "Duplex",
      amenities: ["24/7 Security", "Swimming Pool", "Gym", "Clubhouse", "Parking", "Generator", "Elevator"],
    },
    {
      id: 11,
      userId: "user_11",
      title: "2 Bedroom Modern Flat",
      location: "Shantinagar, Dhaka",
      price: "৳ 22,000/month",
      size: "1,000 sqft",
      bedrooms: 2,
      bathrooms: 2,
      image: "/modern-apartment-shantinagar-dhaka.jpg",
      images: ["/modern-apartment-shantinagar-dhaka.jpg"],
      description:
        "Modern 2-bedroom flat in central Shantinagar location. Well-maintained building with good ventilation and natural light. Close to Hatirpool, Karwan Bazar, and major business districts. Excellent connectivity to all parts of Dhaka.",
      propertyType: "Flat",
      amenities: ["Lift Service", "Parking", "Security", "Gas Connection"],
    },
    {
      id: 12,
      userId: "user_12",
      title: "3 Bedroom Sea View",
      location: "Patenga, Chittagong",
      price: "৳ 40,000/month",
      size: "1,700 sqft",
      bedrooms: 3,
      bathrooms: 3,
      image: "/sea-view-apartment-patenga-chittagong-bangladesh.jpg",
      images: ["/sea-view-apartment-patenga-chittagong-bangladesh.jpg"],
      description:
        "Beautiful apartment with stunning sea views in Chittagong's Patenga area. Wake up to the sound of waves and enjoy breathtaking sunsets from your balcony. Features spacious rooms and modern amenities. Perfect for those who love coastal living.",
      propertyType: "Apartment",
      amenities: ["Sea View", "Balcony", "Parking", "Security", "Generator"],
    },
  ],
}

export default function LatestFlats({ user, filters }) {
  const { searchType, onSearchTypeChange } = useSearch()
  const [properties, setProperties] = useState(defaultProperties)
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const propertiesPerPage = 3

  const [totalProperties, setTotalProperties] = useState(0)
  const [isUsingDefault, setIsUsingDefault] = useState(false)

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        setLoading(true)
        let queryString = `/api/properties/get?type=${searchType}&page=${currentPage}&limit=${propertiesPerPage}`
        if (filters) {
          const { location, propertyType, priceRange, size } = filters
          if (location) queryString += `&location=${location}`
          if (propertyType && propertyType !== "All Types") queryString += `&propertyType=${propertyType}`
          if (priceRange && priceRange !== "Any Price" && priceRange !== "Any Rent")
            queryString += `&priceRange=${priceRange}`
          if (size && size !== "Any Size") queryString += `&size=${size}`
        }
        const response = await fetch(queryString)
        const data = await response.json()
        if (data.success) {
          if (data.totalProperties > 0) {
            setProperties((prev) => ({ ...prev, [searchType]: data.properties }))
            setTotalProperties(data.totalProperties)
            setIsUsingDefault(false)
          } else {
            setProperties((prev) => ({ ...prev, [searchType]: [] }))
            setTotalProperties(0)
            setIsUsingDefault(false)
          }
        }
      } catch (error) {
        console.error("[v0] Error fetching properties:", error)
        setProperties((prev) => ({ ...prev, [searchType]: defaultProperties[searchType] }))
        setTotalProperties(defaultProperties[searchType].length)
        setIsUsingDefault(true)
      } finally {
        setLoading(false)
      }
    }
    fetchProperties()
  }, [searchType, currentPage, filters])

  const totalPages = Math.ceil(totalProperties / propertiesPerPage)
  const allPropertiesForTab = properties[searchType] || []
  let currentProperties = allPropertiesForTab

  if (isUsingDefault) {
    const indexOfLastProperty = currentPage * propertiesPerPage
    const indexOfFirstProperty = indexOfLastProperty - propertiesPerPage
    currentProperties = allPropertiesForTab.slice(indexOfFirstProperty, indexOfLastProperty)
  }

  const handlePageChange = (pageNumber) => {
    if (pageNumber < 1 || pageNumber > totalPages) return
    setCurrentPage(pageNumber)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-(--color-foreground) mb-4 font-heading">Latest Flats</h2>
          <p className="text-(--color-primary) text-lg font-semibold">Discover the newest properties in Bangladesh</p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          {["buy", "rent"].map((tab) => (
            <button
              key={tab}
              onClick={() => {
                onSearchTypeChange(tab)
                setCurrentPage(1)
              }}
              className={`px-8 py-3 rounded-lg font-semibold text-lg capitalize transition-all ${
                searchType === tab
                  ? "bg-(--color-primary) text-white shadow-lg"
                  : "bg-(--color-surface) text-(--color-foreground) hover:bg-(--color-surface-hover)"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Property Grid */}
        {currentProperties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentProperties.map((property) => (
              <PropertyCard key={property._id || property.id} property={property} user={user} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600 text-lg">No properties found matching your criteria.</p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-12 flex justify-center">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault()
                      handlePageChange(currentPage - 1)
                    }}
                  />
                </PaginationItem>
                {[...Array(totalPages).keys()].map((number) => (
                  <PaginationItem key={number + 1}>
                    <PaginationLink
                      href="#"
                      isActive={currentPage === number + 1}
                      onClick={(e) => {
                        e.preventDefault()
                        handlePageChange(number + 1)
                      }}
                    >
                      {number + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault()
                      handlePageChange(currentPage + 1)
                    }}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        )}
      </div>
    </section>
  )
}
