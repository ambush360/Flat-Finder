"use client"

import { useState } from "react"
import { X, MapPin, DollarSign, Ruler, Bed, Bath } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function AddRentModal({ isOpen, onClose, userId }) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [formData, setFormData] = useState({
    title: "",
    location: "",
    price: "",
    size: "",
    bedrooms: "",
    bathrooms: "",
    description: "",
    propertyType: "Flat",
    amenities: "",
    images: [],
  })

  const handleInputChange = (e) => {
    let { name, value } = e.target
    if (name === "price" || name === "size") {
      value = value.replace(/,/g, "")
    }
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files)
    if (files.length > 5) {
      setError("You can only upload a maximum of 5 images.")
      return
    }
    setFormData((prev) => ({
      ...prev,
      images: files,
    }))
    setError("")
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const submissionData = new FormData()
      Object.keys(formData).forEach((key) => {
        if (key === "images") {
          formData.images.forEach((image) => {
            submissionData.append("images", image)
          })
        } else {
          submissionData.append(key, formData[key])
        }
      })
      submissionData.append("userType", "owner")
      submissionData.append("userId", userId)

      const response = await fetch("/api/properties/add", {
        method: "POST",
        body: submissionData,
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Failed to add property")
        return
      }

      alert("Property added successfully!")
      setFormData({
        title: "",
        location: "",
        price: "",
        size: "",
        bedrooms: "",
        bathrooms: "",
        description: "",
        propertyType: "Flat",
        amenities: "",
        images: [],
      })
      onClose()
      window.location.reload()
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error("[v0] Error adding property:", err)
    } finally {
      setLoading(false)
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors z-10"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Add Property for Rent</h2>
            <p className="text-gray-600 text-sm">List your property for rent on our platform</p>
          </div>

          {error && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Property Title</label>
                <Input
                  type="text"
                  name="title"
                  placeholder="e.g., 3 Bedroom Luxury Apartment"
                  value={formData.title}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="text"
                    name="location"
                    placeholder="e.g., Gulshan 2, Dhaka"
                    className="pl-10"
                    value={formData.location}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Monthly Rent (৳)</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="number"
                    name="price"
                    placeholder="e.g., 25,000"
                    className="pl-10"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Size (sqft)</label>
                <div className="relative">
                  <Ruler className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="number"
                    name="size"
                    placeholder="e.g., 1,850"
                    className="pl-10"
                    value={formData.size}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Bedrooms</label>
                <div className="relative">
                  <Bed className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="number"
                    name="bedrooms"
                    placeholder="e.g., 3"
                    className="pl-10"
                    value={formData.bedrooms}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Bathrooms</label>
                <div className="relative">
                  <Bath className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="number"
                    name="bathrooms"
                    placeholder="e.g., 2"
                    className="pl-10"
                    value={formData.bathrooms}
                    onChange={handleInputChange}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-900 mb-2">Property Type</label>
                <select
                  name="propertyType"
                  value={formData.propertyType}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>Flat</option>
                  <option>Apartment</option>
                  <option>House</option>
                  <option>Duplex</option>
                  <option>Studio</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Description</label>
              <textarea
                name="description"
                placeholder="Describe your property in detail..."
                value={formData.description}
                onChange={handleInputChange}
                rows="4"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Amenities (comma-separated)</label>
              <Input
                type="text"
                name="amenities"
                placeholder="e.g., Lift, Parking, Security, Generator"
                value={formData.amenities}
                onChange={handleInputChange}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-900 mb-2">Property Images (Max 5)</label>
              <Input
                type="file"
                name="images"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="w-full"
              />
              <div className="mt-4 grid grid-cols-5 gap-4">
                {formData.images.map((file, index) => (
                  <div key={index} className="relative">
                    <img
                      src={URL.createObjectURL(file)}
                      alt={`preview ${index}`}
                      className="w-full h-24 object-cover rounded-lg"
                    />
                  </div>
                ))}
              </div>
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 disabled:opacity-50"
            >
              {loading ? "Adding Property..." : "Add Property"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}