"use client"

import { useState } from "react"
import { X, Copy, MessageCircle, Mail, Phone } from "lucide-react"

export default function ShareModal({ property, isOpen, onClose }) {
  const [shareLink, setShareLink] = useState("")
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  const generateShareLink = async () => {
    if (shareLink) return

    setLoading(true)
    try {
      const response = await fetch("/api/share/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ propertyId: property._id }),
      })

      const data = await response.json()
      if (data.success) {
        const link = `${typeof window !== "undefined" ? window.location.origin : ""}/share/${data.shareId}`
        setShareLink(link)
      }
    } catch (error) {
      console.error("Error generating share link:", error)
      alert("Failed to generate share link")
    } finally {
      setLoading(false)
    }
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleWhatsApp = () => {
    if (!shareLink) return
    const text = `Check out this property: ${property.title} - ${shareLink}`
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank")
  }

  const handleMessenger = () => {
    if (!shareLink) return
    window.open(
      `https://www.facebook.com/dialog/send?app_id=YOUR_APP_ID&link=${encodeURIComponent(shareLink)}&redirect_uri=${encodeURIComponent(shareLink)}`,
      "_blank",
    )
  }

  const handleEmail = () => {
    if (!shareLink) return
    const subject = `Check out this property: ${property.title}`
    const body = `I found this amazing property for you:\n\n${property.title}\nLocation: ${property.location}\nPrice: ${property.price}\n\nView it here: ${shareLink}`
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  const handleSMS = () => {
    if (!shareLink) return
    const text = `Check out this property: ${property.title} - ${shareLink}`
    window.location.href = `sms:?body=${encodeURIComponent(text)}`
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-md w-full shadow-xl" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Share Property</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Generate Link Button */}
          {!shareLink && (
            <button
              onClick={generateShareLink}
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition-colors disabled:opacity-50 mb-4"
            >
              {loading ? "Generating..." : "Generate Share Link"}
            </button>
          )}

          {/* Share Link */}
          {shareLink && (
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Share Link</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={shareLink}
                  readOnly
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm"
                />
                <button
                  onClick={handleCopyLink}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-900 px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
                >
                  <Copy className="w-4 h-4" />
                  {copied ? "Copied!" : "Copy"}
                </button>
              </div>
            </div>
          )}

          {/* Share Options */}
          {shareLink && (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-gray-700 mb-3">Share via:</p>

              <button
                onClick={handleWhatsApp}
                className="w-full flex items-center gap-3 px-4 py-3 bg-green-50 hover:bg-green-100 text-green-700 rounded-lg transition-colors font-semibold"
              >
                <MessageCircle className="w-5 h-5" />
                WhatsApp
              </button>

              <button
                onClick={handleMessenger}
                className="w-full flex items-center gap-3 px-4 py-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors font-semibold"
              >
                <MessageCircle className="w-5 h-5" />
                Messenger
              </button>

              <button
                onClick={handleEmail}
                className="w-full flex items-center gap-3 px-4 py-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg transition-colors font-semibold"
              >
                <Mail className="w-5 h-5" />
                Email
              </button>

              <button
                onClick={handleSMS}
                className="w-full flex items-center gap-3 px-4 py-3 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-lg transition-colors font-semibold"
              >
                <Phone className="w-5 h-5" />
                SMS
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
