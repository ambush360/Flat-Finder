"use client"

import { useState } from "react"
import { X, Mail, Lock, Phone, Upload, User, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import AddPropertyModal from "@/components/add-property-modal"
import AddRentModal from "@/components/add-rent-modal"

export default function AuthModal({ isOpen, onClose }) {
  const [isSignUp, setIsSignUp] = useState(false)
  const [userType, setUserType] = useState("buyer")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [showPropertyForm, setShowPropertyForm] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const [nidImage, setNidImage] = useState(null)
  const [nidImagePreview, setNidImagePreview] = useState(null)

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    city: "",
    password: "",
  })

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSignUp = async (e) => {
    if (e) e.preventDefault()
    setLoading(true)
    setError("")

    try {
      let nidImageUrl = ""
      if (nidImage) {
        const data = new FormData()
        data.append("file", nidImage)
        data.append("upload_preset", "flat-buy-sell-rent") // Create an upload preset in Cloudinary
        const res = await fetch(`https://api.cloudinary.com/v1_1/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/image/upload`, {
          method: "POST",
          body: data,
        })
        const file = await res.json()
        nidImageUrl = file.secure_url
      }

      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          userType,
          nidImageUrl,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Registration failed")
        return
      }

      if (userType === "seller" || userType === "owner") {
        setCurrentUser(data.user)
        setShowPropertyForm(true)
        setIsSignUp(false)
      } else {
        alert("Account created successfully! Please sign in.")
        setIsSignUp(false)
        setFormData({ name: "", phone: "", email: "", city: "", password: "" })
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error("[v0] Sign up error:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: formData.phone,
          password: formData.password,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Login failed")
        return
      }

      alert("Login successful!")
      localStorage.setItem("user", JSON.stringify(data.user))
      onClose()
      setFormData({ name: "", phone: "", email: "", city: "", password: "" })
      window.location.reload()
    } catch (err) {
      setError("An error occurred. Please try again.")
      console.error("[v0] Login error:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleOAuthLogin = (provider) => {
    // Redirect to OAuth provider
    const redirectUrl = `${window.location.origin}/api/auth/oauth/${provider}`
    window.location.href = redirectUrl
  }

  const handleClosePropertyForm = () => {
    setShowPropertyForm(false)
    onClose()
    setFormData({ name: "", phone: "", email: "", city: "", password: "" })
  }

  if (showPropertyForm && currentUser) {
    if (currentUser.userType === "owner") {
      return (
        <AddRentModal
          isOpen={showPropertyForm}
          onClose={handleClosePropertyForm}
          userId={currentUser._id}
        />
      )
    }
    return (
      <AddPropertyModal
        isOpen={showPropertyForm}
        onClose={handleClosePropertyForm}
        userType={currentUser.userType}
        userId={currentUser._id}
      />
    )
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Background Image */}
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <img src="/modern-dhaka-skyline-apartment-buildings.jpg" alt="" className="w-full h-full object-cover" />
        </div>

        {/* Content */}
        <div className="relative p-6">
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-(--color-surface) rounded-full transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-(--color-foreground) mb-2 font-heading">
              {isSignUp ? "Create Account" : "Welcome Back"}
            </h2>
            <p className="text-(--color-muted) text-sm">
              {isSignUp
                  ? "Join Bangladesh's trusted real estate platform"
                  : "Sign in to continue"}
            </p>
          </div>

          {/* Main Auth Screen */}
            <>
              {/* User Type Selection */}
              {isSignUp && (
                <div className="mb-6">
                  <label className="block text-sm font-medium text-(--color-foreground) mb-3">I am a</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: "buyer", label: "Buyer" },
                      { value: "seller", label: "Seller" },
                      { value: "owner", label: "House Owner" },
                      { value: "renter", label: "Renter" },
                    ].map((type) => (
                      <button
                        key={type.value}
                        onClick={() => setUserType(type.value)}
                        className={`px-4 py-2 rounded-lg border-2 font-medium transition-all ${
                          userType === type.value
                            ? "border-(--color-primary) bg-(--color-primary) text-white"
                            : "border-(--color-border) bg-white text-(--color-foreground) hover:border-(--color-primary)"
                        }`}
                      >
                        {type.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}


              {error && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm">{error}</div>}

              {/* Form */}
              <form
                onSubmit={isSignUp ? handleSignUp : handleLogin}
                className="space-y-4"
              >
                {isSignUp && (
                  <div>
                    <label className="block text-sm font-medium text-(--color-foreground) mb-2">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                      <Input
                        type="text"
                        name="name"
                        placeholder="Enter your full name"
                        className="pl-10"
                        value={formData.name}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-(--color-foreground) mb-2">Phone Number</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                    <Input
                      type="tel"
                      name="phone"
                      placeholder="+880XXXXXXXXXX"
                      className="pl-10"
                      value={formData.phone}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                {isSignUp && (
                  <div>
                    <label className="block text-sm font-medium text-(--color-foreground) mb-2">Email (Optional)</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                      <Input
                        type="email"
                        name="email"
                        placeholder="your@email.com"
                        className="pl-10"
                        value={formData.email}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                )}

                {isSignUp && (
                  <div>
                    <label className="block text-sm font-medium text-(--color-foreground) mb-2">City</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                      <Input
                        type="text"
                        name="city"
                        placeholder="e.g., Dhaka, Chittagong"
                        className="pl-10"
                        value={formData.city}
                        onChange={handleInputChange}
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-(--color-foreground) mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-(--color-muted)" />
                    <Input
                      type="password"
                      name="password"
                      placeholder="••••••••"
                      className="pl-10"
                      value={formData.password}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                {isSignUp && (
                  <div>
                    <label className="block text-sm font-medium text-(--color-foreground) mb-2">NID Verification</label>
                    <div className="border-2 border-dashed border-(--color-border) rounded-lg p-4 text-center hover:border-(--color-primary) transition-colors cursor-pointer">
                      <input
                        type="file"
                        className="hidden"
                        id="nid-upload"
                        onChange={(e) => {
                          const file = e.target.files[0]
                          setNidImage(file)
                          if (file) {
                            setNidImagePreview(URL.createObjectURL(file))
                          } else {
                            setNidImagePreview(null)
                          }
                        }}
                      />
                      <label htmlFor="nid-upload" className="cursor-pointer">
                        {nidImagePreview ? (
                          <img src={nidImagePreview} alt="NID Preview" className="w-full h-auto rounded-lg" />
                        ) : (
                          <>
                            <Upload className="w-8 h-8 text-(--color-muted) mx-auto mb-2" />
                            <p className="text-sm text-(--color-muted)">
                              {nidImage ? nidImage.name : "Upload NID or Enter NID Number"}
                            </p>
                          </>
                        )}
                      </label>
                    </div>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-(--color-primary) hover:bg-(--color-primary-hover) text-white font-medium py-3 disabled:opacity-50"
                >
                  {loading ? "Processing..." : isSignUp ? "Sign Up" : "Sign In"}
                </Button>
              </form>

              {/* Toggle Sign In/Up */}
              <div className="mt-6 text-center">
                <button
                  onClick={() => {
                    setIsSignUp(!isSignUp)
                    setError("")
                    setFormData({ name: "", phone: "", email: "", city: "", password: "" })
                  }}
                  className="text-sm text-(--color-primary) hover:underline font-medium"
                >
                  {isSignUp ? "Already have an account? Sign In" : "Don't have an account? Sign Up"}
                </button>
              </div>
            </>
        </div>
      </div>
    </div>
  )
}
