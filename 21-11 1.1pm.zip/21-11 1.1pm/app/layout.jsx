import { Inter, Poppins } from "next/font/google"
import Header from "@/components/header"
import { SearchProvider } from "@/context/SearchContext"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
})

export const metadata = {
  title: "Flat Buy Sell & Rent - Bangladesh Real Estate",
  description:
    "Find your perfect home in Bangladesh. Buy, sell, or rent properties across Dhaka, Chittagong, and more.",
  generator: "v0.app",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${inter.variable} ${poppins.variable}`}>
      <body>
        <SearchProvider>
          <Header />
          {children}
        </SearchProvider>
      </body>
    </html>
  )
}
