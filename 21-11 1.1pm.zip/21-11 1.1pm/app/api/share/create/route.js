import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request) {
  try {
    const { propertyId } = await request.json()

    if (!propertyId) {
      return Response.json({ success: false, error: "Property ID is required" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    // Create a share record
    const shareRecord = {
      propertyId: new ObjectId(propertyId),
      createdAt: new Date(),
      views: 0,
    }

    const result = await db.collection("shares").insertOne(shareRecord)

    return Response.json({
      success: true,
      shareId: result.insertedId.toString(),
    })
  } catch (error) {
    console.error("Error creating share:", error)
    return Response.json({ success: false, error: error.message }, { status: 500 })
  }
}
