import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request, { params }) {
  try {
    const { shareId } = params

    if (!shareId) {
      return Response.json({ success: false, error: "Share ID is required" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    // Get share record
    const shareRecord = await db.collection("shares").findOne({
      _id: new ObjectId(shareId),
    })

    if (!shareRecord) {
      return Response.json({ success: false, error: "Share not found" }, { status: 404 })
    }

    // Get property
    const property = await db.collection("properties").findOne({
      _id: shareRecord.propertyId,
    })

    if (!property) {
      return Response.json({ success: false, error: "Property not found" }, { status: 404 })
    }

    // Update view count
    await db.collection("shares").updateOne({ _id: new ObjectId(shareId) }, { $inc: { views: 1 } })

    return Response.json({
      success: true,
      property,
    })
  } catch (error) {
    console.error("Error fetching shared property:", error)
    return Response.json({ success: false, error: error.message }, { status: 500 })
  }
}
