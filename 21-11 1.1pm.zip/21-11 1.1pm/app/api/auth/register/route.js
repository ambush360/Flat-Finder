import { connectToDatabase } from "@/lib/mongodb"
import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"

export async function POST(request) {
  try {
    const { name, phone, email, city, password, userType, nidImageUrl, otpVerified, oauthProvider, oauthId } =
      await request.json()

    // Validation
    if (!name || !phone || (!password && !oauthProvider)) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // Check if user already exists
    const existingUser = await usersCollection.findOne({
      $or: [{ phone }, ...[email && { email }], ...[oauthId && { oauthId }]].filter(Boolean),
    })

    if (existingUser) {
      return NextResponse.json({ error: "User already exists" }, { status: 400 })
    }

    // Create new user
    const newUser = {
      name,
      phone,
      email: email || null,
      city: city || null,
      password: await bcrypt.hash(password, 10),
      userType,
      nidImageUrl: nidImageUrl || null,
      oauthProvider: oauthProvider || null,
      oauthId: oauthId || null,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await usersCollection.insertOne(newUser)

    return NextResponse.json(
      {
        message: "User registered successfully",
        user: {
          _id: result.insertedId,
          name,
          phone,
          email,
          city,
          userType,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("[v0] Registration error:", error)
    return NextResponse.json({ error: "Registration failed" }, { status: 500 })
  }
}
