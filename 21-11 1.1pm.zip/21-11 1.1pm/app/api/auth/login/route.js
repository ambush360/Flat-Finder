import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"
import { NextResponse } from "next/server"
import bcrypt from "bcryptjs"

export async function POST(request) {
  try {
    const { phone, password } = await request.json()

    console.log(phone,password)

    // Validation
    if (!phone || !password) {
      return NextResponse.json({ error: "Phone and password are required" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const usersCollection = db.collection("users")

    // Find user
    const user = await usersCollection.findOne({ phone })

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 401 })
    }

    const isMatch = await bcrypt.compare(password, user.password);

    // Check password (In production, use bcrypt to compare hashed passwords!)
    if (!isMatch) {
      return NextResponse.json({ error: "Invalid password" }, { status: 401 })
    }

    // Log login attempt
    const logsCollection = db.collection("login_logs")
    await logsCollection.insertOne({
      userId: user._id,
      phone,
      loginTime: new Date(),
      success: true,
    })


    // Return user data (without password)
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json(
      {
        message: "Login successful",
        user: userWithoutPassword,
      },
      { status: 200 },
    )
  } catch (error) {
    console.error("[v0] Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
