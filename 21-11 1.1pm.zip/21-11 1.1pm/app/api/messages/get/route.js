import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const groupId = searchParams.get("groupId")

    if (!userId) {
      return Response.json({ error: "Missing userId" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    let query = {}

    if (groupId) {
      query = { groupId: new ObjectId(groupId) }
    } else {
      query = {
        $or: [{ senderId: new ObjectId(userId) }, { receiverId: new ObjectId(userId) }],
      }
    }

    const messages = await db.collection("messages").find(query).sort({ createdAt: 1 }).toArray()

    return Response.json({ messages })
  } catch (error) {
    console.error("Error fetching messages:", error)
    return Response.json({ error: "Failed to fetch messages" }, { status: 500 })
  }
}
