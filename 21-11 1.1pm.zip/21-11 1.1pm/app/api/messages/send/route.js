import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request) {
  try {
    const { senderId, receiverId, message, groupId } = await request.json()

    if (!senderId || !message) {
      return Response.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    const messageData = {
      senderId: new ObjectId(senderId),
      receiverId: receiverId ? new ObjectId(receiverId) : null,
      groupId: groupId ? new ObjectId(groupId) : null,
      message,
      createdAt: new Date(),
      read: false,
    }

    const result = await db.collection("messages").insertOne(messageData)

    return Response.json({ success: true, messageId: result.insertedId })
  } catch (error) {
    console.error("Error sending message:", error)
    return Response.json({ error: "Failed to send message" }, { status: 500 })
  }
}
