import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request) {
  try {
    const { groupId, userId } = await request.json()

    if (!groupId || !userId) {
      return Response.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    const result = await db
      .collection("groups")
      .updateOne({ _id: new ObjectId(groupId) }, { $addToSet: { members: new ObjectId(userId) } })

    return Response.json({ success: true, modifiedCount: result.modifiedCount })
  } catch (error) {
    console.error("Error adding member:", error)
    return Response.json({ error: "Failed to add member" }, { status: 500 })
  }
}
