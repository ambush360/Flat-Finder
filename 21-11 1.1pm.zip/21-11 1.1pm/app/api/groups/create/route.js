import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function POST(request) {
  try {
    const { groupName, adminId, members } = await request.json()

    if (!groupName || !adminId) {
      return Response.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    const groupData = {
      groupName,
      adminId: new ObjectId(adminId),
      members: members ? members.map((id) => new ObjectId(id)) : [new ObjectId(adminId)],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("groups").insertOne(groupData)

    return Response.json({ success: true, groupId: result.insertedId })
  } catch (error) {
    console.error("Error creating group:", error)
    return Response.json({ error: "Failed to create group" }, { status: 500 })
  }
}
