import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const isAdmin = searchParams.get("isAdmin") === "true"

    if (!userId) {
      return Response.json({ error: "Missing userId" }, { status: 400 })
    }

    const { db } = await connectToDatabase()

    let query = {}

    if (isAdmin) {
      query = { adminId: new ObjectId(userId) }
    } else {
      query = { members: new ObjectId(userId) }
    }

    const groups = await db.collection("groups").find(query).toArray()

    return Response.json({ groups })
  } catch (error) {
    console.error("Error fetching groups:", error)
    return Response.json({ error: "Failed to fetch groups" }, { status: 500 })
  }
}
