import { connectToDatabase } from "@/lib/mongodb"

const parsePrice = str => {
  if (!str) return NaN
  const value = parseFloat(str)
  if (str.toLowerCase().includes("cr")) {
    return value * 10000000
  }
  if (str.toLowerCase().includes("l")) {
    return value * 100000
  }
  return value
}

export async function GET(request) {
  try {
    const { db } = await connectToDatabase()
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")
    const page = parseInt(searchParams.get("page")) || 1
    const limit = parseInt(searchParams.get("limit")) || 6
    const skip = (page - 1) * limit
    const location = searchParams.get("location")
    const propertyType = searchParams.get("propertyType")
    const price = searchParams.get("price")
    const size = searchParams.get("size")

    let collectionName
    if (type === "buy") {
      collectionName = "properties_for_sale"
    } else if (type === "rent") {
      collectionName = "properties_for_rent"
    } else {
      return Response.json({ success: true, properties: [], totalProperties: 0 }, { status: 200 })
    }

    const query = {}
    if (location) {
      query.location = { $regex: location, $options: "i" }
    }
    if (propertyType) {
      query.propertyType = propertyType
    }

    const exprConditions = []
    if (price) {
      const [minPriceStr, maxPriceStr] = price.split("-")
      const minPrice = parsePrice(minPriceStr)
      const maxPrice = parsePrice(maxPriceStr)

      if (!isNaN(minPrice)) {
        exprConditions.push({ $gte: [{ $toInt: "$price" }, minPrice] })
      }
      if (!isNaN(maxPrice)) {
        exprConditions.push({ $lte: [{ $toInt: "$price" }, maxPrice] })
      }
    }

    if (size) {
      const [minSizeStr, maxSizeStr] = size.split("-")
      const minSize = parseInt(minSizeStr, 10)
      const maxSize = parseInt(maxSizeStr, 10)

      if (!isNaN(minSize)) {
        exprConditions.push({ $gte: [{ $toInt: "$size" }, minSize] })
      }
      if (!isNaN(maxSize)) {
        exprConditions.push({ $lte: [{ $toInt: "$size" }, maxSize] })
      }
    }

    if (exprConditions.length > 0) {
      query.$expr = { $and: exprConditions }
    }

    const collection = db.collection(collectionName)
    const totalProperties = await collection.countDocuments(query)
    const properties = await collection.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).toArray()

    return Response.json({ success: true, properties, totalProperties }, { status: 200 })
  } catch (error) {
    console.error("[v0] Error fetching properties:", error)
    return Response.json({ error: "Failed to fetch properties" }, { status: 500 })
  }
}
