import { connectToDatabase } from "@/lib/mongodb"
import { NextResponse } from "next/server"

export async function GET(request) {
  try {
    const { db } = await connectToDatabase()
    const propertiesCollection = db.collection("properties")

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") // buy, rent, sell

    const query = {}
    if (type) {
      query.type = type
    }

    const properties = await propertiesCollection.find(query).toArray()

    return NextResponse.json({ properties }, { status: 200 })
  } catch (error) {
    console.error("[v0] Get properties error:", error)
    return NextResponse.json({ error: "Failed to fetch properties" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const propertyData = await request.json()

    // Validation
    if (!propertyData.title || !propertyData.location || !propertyData.price) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const { db } = await connectToDatabase()
    const propertiesCollection = db.collection("properties")

    // Add property
    const newProperty = {
      ...propertyData,
      createdAt: new Date(),
    }

    const result = await propertiesCollection.insertOne(newProperty)

    return NextResponse.json(
      {
        message: "Property added successfully",
        propertyId: result.insertedId,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("[v0] Add property error:", error)
    return NextResponse.json({ error: "Failed to add property" }, { status: 500 })
  }
}
