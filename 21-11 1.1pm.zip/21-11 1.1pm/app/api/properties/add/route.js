import { connectToDatabase } from "@/lib/mongodb"
import { writeFile } from "fs/promises"
import { join } from "path"

export async function POST(request) {
  try {
    const { db } = await connectToDatabase()
    const formData = await request.formData()

    const {
      title,
      location,
      price,
      size,
      bedrooms,
      bathrooms,
      description,
      propertyType,
      amenities,
      userType,
      userId,
    } = Object.fromEntries(formData.entries())

    const images = formData.getAll("images")
    const imageUrls = []

    for (const image of images) {
      const bytes = await image.arrayBuffer()
      const buffer = Buffer.from(bytes)
      const path = join(process.cwd(), "public/uploads", image.name)
      await writeFile(path, buffer)
      imageUrls.push(`/uploads/${image.name}`)
    }

    if (!title || !location || !price || !userType) {
      return Response.json({ error: "Missing required fields" }, { status: 400 })
    }

    const collection = userType === "seller" ? "properties_for_sale" : userType === "owner" ? "properties_for_rent" : "properties_for_rent"

    const newProperty = {
      title,
      location,
      price: Number.parseInt(price) || 0,
      size: Number.parseInt(size) || 0,
      bedrooms: Number.parseInt(bedrooms) || 0,
      bathrooms: Number.parseInt(bathrooms) || 0,
      description,
      propertyType,
      amenities: amenities ? amenities.split(",").map((a) => a.trim()) : [],
      userId,
      userType,
      images: imageUrls,
      image: imageUrls[0] || "/diverse-property-showcase.png",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection(collection).insertOne(newProperty)

    return Response.json(
      {
        success: true,
        message: "Property added successfully",
        propertyId: result.insertedId,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("[v0] Error adding property:", error)
    return Response.json({ error: "Failed to add property" }, { status: 500 })
  }
}
