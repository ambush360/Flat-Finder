import React from 'react';

const RentPropertyPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Rent Property — ভাড়া নেওয়া/দেওয়া সহজ করে দিই</h1>
      <p className="mb-6">
        চাইলে ভাড়া নিতে চান বা ভাড়া দেবেন — দুটো ক্ষেত্রেই আমরা নিরাপত্তা ও নির্ভরযোগ্যতা নিশ্চিত করি। ভাড়ার চুক্তি, ডিপোজিট, পেমেন্ট প্ল্যান ও সম্পত্তি দেখানো — সবকিছুতেই সহায়তা।
      </p>

      <h2 className="text-2xl font-bold mb-4">ফিচার / সুবিধা:</h2>
      <ul className="list-disc list-inside mb-6 space-y-2">
        <li>ভূমি/ফ্ল্যাট/কক্ষের বিভাজন ও সুলিখিত লিস্টিং।</li>
        <li>সিকিউরিটি চেক ও ভেরিফিকেশন — ভাড়াটিয়া/ভাড়াাদাতার যাচাই।</li>
        <li>চুক্তি টেমপ্লেট ও কাগজপত্র — সময়মতো লিজ, ডিপোজিট ফিরতি শর্ত ইত্যাদি।</li>
        <li>পেমেন্ট ট্র্যাকিং ও রিমাইন্ডার — ভাড়া আদায় ট্র্যাকিং।</li>
        <li>রিয়েল-টাইম যোগাযোগ — ভাড়ার জন্য দ্রুত যোগাযোগ ও ভিজিট সেটআপ।</li>
      </ul>

      <h2 className="text-2xl font-bold mb-4">যেভাবে শুরু করবেন (Quick Steps):</h2>
      <ol className="list-decimal list-inside space-y-2">
        <li>আপনার বাজেট/অঞ্চল/বেডরুম প্রয়োজন নির্ধারণ করুন।</li>
        <li>লিস্টিং দেখুন ও পছন্দ হলে ভিজিট বুক করুন।</li>
        <li>যাচাই ও কাগজপত্র চেক করে চূড়ান্ত চুক্তি করুন।</li>
      </ol>
    </div>
  );
};

export default RentPropertyPage;