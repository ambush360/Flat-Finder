"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { Heart, Share2, Bed, Bath, Maximize, MapPin, Calendar, Home, ChevronLeft, ChevronRight } from "lucide-react"

export default function SharedPropertyPage() {
  const params = useParams()
  const [property, setProperty] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)

  useEffect(() => {
    const fetchSharedProperty = async () => {
      try {
        const response = await fetch(`/api/share/get/${params.shareId}`)
        const data = await response.json()

        if (data.success) {
          setProperty(data.property)
        } else {
          setError("Property not found")
        }
      } catch (err) {
        setError("Failed to load property")
        console.error(err)
      } finally {
        setLoading(false)
      }
    }

    if (params.shareId) {
      fetchSharedProperty()
    }
  }, [params.shareId])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading property...</p>
        </div>
      </div>
    )
  }

  if (error || !property) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <p className="text-red-600 text-lg mb-4">{error || "Property not found"}</p>
          <a href="/" className="text-blue-600 hover:underline">
            Back to home
          </a>
        </div>
      </div>
    )
  }

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length)
  }

  const shareUrl = typeof window !== "undefined" ? window.location.href : ""

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl)
    alert("Link copied to clipboard!")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href="/" className="text-2xl font-bold text-blue-600">
            FlatBuySellRent
          </a>
          <button
            onClick={handleCopyLink}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
          >
            <Share2 className="w-4 h-4" />
            Share Link
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Image Slider */}
          <div className="relative h-96 bg-gray-100">
            <img
              src={property.images[currentImageIndex] || "/placeholder.svg"}
              alt={property.title}
              className="w-full h-full object-cover"
            />

            {/* Image Navigation */}
            {property.images.length > 1 && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-6 h-6 text-gray-900" />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-6 h-6 text-gray-900" />
                </button>

                {/* Image Counter */}
                <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                  {currentImageIndex + 1} / {property.images.length}
                </div>
              </>
            )}

            {/* Action Buttons */}
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                onClick={() => setIsFavorite(!isFavorite)}
                className="bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                aria-label="Add to favorites"
              >
                <Heart className={`w-5 h-5 ${isFavorite ? "fill-red-500 text-red-500" : "text-gray-900"}`} />
              </button>
              <button
                onClick={handleCopyLink}
                className="bg-white/90 hover:bg-white p-3 rounded-full shadow-lg transition-colors"
                aria-label="Share property"
              >
                <Share2 className="w-5 h-5 text-gray-900" />
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="p-8">
            {/* Price and Location */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="text-4xl font-bold text-blue-600 mb-2">{property.price}</div>
                <div className="flex items-center gap-2 text-gray-600 text-lg">
                  <MapPin className="w-5 h-5" />
                  <span>{property.location}</span>
                </div>
              </div>
            </div>

            {/* Property Features */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 p-6 bg-gray-50 rounded-lg">
              {property.bedrooms > 0 && (
                <div className="flex items-center gap-3">
                  <Bed className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Bedrooms</div>
                    <div className="font-semibold text-gray-900">{property.bedrooms}</div>
                  </div>
                </div>
              )}
              {property.bathrooms > 0 && (
                <div className="flex items-center gap-3">
                  <Bath className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Bathrooms</div>
                    <div className="font-semibold text-gray-900">{property.bathrooms}</div>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3">
                <Maximize className="w-6 h-6 text-blue-600" />
                <div>
                  <div className="text-sm text-gray-500">Size</div>
                  <div className="font-semibold text-gray-900">{property.size}</div>
                </div>
              </div>
              {property.propertyType && (
                <div className="flex items-center gap-3">
                  <Home className="w-6 h-6 text-blue-600" />
                  <div>
                    <div className="text-sm text-gray-500">Type</div>
                    <div className="font-semibold text-gray-900">{property.propertyType}</div>
                  </div>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Description</h3>
              <p className="text-gray-700 leading-relaxed text-lg">
                {property.description ||
                  "This beautiful property offers modern living spaces with excellent amenities. Located in a prime area with easy access to schools, shopping centers, and transportation. Perfect for families looking for comfort and convenience in the heart of the city."}
              </p>
            </div>

            {/* Amenities */}
            {property.amenities && property.amenities.length > 0 && (
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Amenities</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {property.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center gap-3 text-gray-700">
                      <div className="w-3 h-3 bg-blue-600 rounded-full" />
                      <span>{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Additional Info */}
            {property.yearBuilt && (
              <div className="flex items-center gap-2 text-gray-600 mb-8 text-lg">
                <Calendar className="w-5 h-5" />
                <span>Built in {property.yearBuilt}</span>
              </div>
            )}

            {/* Contact Button */}
            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-lg transition-colors text-lg">
              Contact Owner
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
