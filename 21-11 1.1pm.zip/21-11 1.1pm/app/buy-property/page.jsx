import React from 'react';

const BuyPropertyPage = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Buy Property — যেভাবে সুবিধা পাবেন</h1>
      <p className="mb-6">
        Flat Buy Sell & Rent-এ বাড়ি/ফ্ল্যাট/জমি কেনা করা সহজ, নিরাপদ এবং স্মার্ট। আমরা স্থানীয় বাজার-জ্ঞান, যাচাই-প্রক্রিয়া এবং ক্রেতা-সাপোর্ট দিয়ে আপনাকে সম্পূর্ণ সহায়তা করি, যাতে সঠিক সময়ে, সঠিক দামে সঠিক সম্পত্তি পেয়ে যান।
      </p>

      <h2 className="text-2xl font-bold mb-4">ফিচার / সুবিধা:</h2>
      <ul className="list-disc list-inside mb-6 space-y-2">
        <li>প্রশস্ত ভেরিফায়েড লিস্টিং — শুধুমাত্র যাচাই করা সম্পত্তি দেখাই।</li>
        <li>অঞ্চলভিত্তিক বাজার বিশ্লেষণ — প্রতিযোগিতামূলক দাম, ভবিষ্যৎ মূল্যবৃদ্ধি।</li>
        <li>ফাইন্যান্সিং গাইড — লোন অপশন, কিস্তি পরিকল্পনা ও কাগজপত্র গাইড।</li>
        <li>আইনি ও কাগজপত্র সহায়তা — রেজিস্ট্রেশন, NOC, চুক্তি পরামর্শ।</li>
        <li>বদলে নেওয়ার (negotiation) সাপোর্ট — বিক্রেতার সাথে দরকষাকষি ও টেকনিক্যাল সহায়তা।</li>
        <li>সাইট ভিজিট ও ভার্চুয়াল ট্যুর — সময়মত ভিজিট সিডিউল ও অনলাইন ট্যুর।</li>
      </ul>

      <h2 className="text-2xl font-bold mb-4">যেভাবে শুরু করবেন (Quick Steps):</h2>
      <ol className="list-decimal list-inside space-y-2">
        <li>প্রয়োজনীয় বাজেট ও এলাকার তালিকা নির্ধারণ করুন।</li>
        <li>আমাদের সাইটে ফিল্টার ব্যবহার করে প্রাথমিক লিস্টিং দেখুন।</li>
        <li>পছন্দ হলে অ্যাপয়েন্টমেন্ট বুক করুন — সাইট ভিজিট/ভার্চুয়াল ট্যুর।</li>
        <li>দরকষাকষি ও কাগজপত্র চূড়ান্ত করুন।</li>
      </ol>
      
      <div className="mt-8">
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Search Properties
        </button>
        <button className="ml-4 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
          Book a Visit
        </button>
      </div>
    </div>
  );
};

export default BuyPropertyPage;