"use client"

import { useState, useEffect } from "react"
import { ArrowLeft, Plus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import ChatInterface from "@/components/chat-interface"
import GroupManagement from "@/components/group-management"

export default function MessagesPage() {
  const [currentUser, setCurrentUser] = useState(null)
  const [selectedChat, setSelectedChat] = useState(null)
  const [groups, setGroups] = useState([])
  const [showGroupManagement, setShowGroupManagement] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user") || "null")
    setCurrentUser(user)

    if (user) {
      setIsAdmin(user.userType === "admin")
      fetchGroups(user._id)

      const contactOwner = JSON.parse(localStorage.getItem("contactOwner") || "null")
      if (contactOwner) {
        setSelectedChat({ type: "user", ...contactOwner })
        localStorage.removeItem("contactOwner")
      }
    }
  }, [])

  const fetchGroups = async (userId) => {
    try {
      const response = await fetch(`/api/groups/get?userId=${userId}&isAdmin=${isAdmin}`)
      const data = await response.json()
      setGroups(data.groups || [])
    } catch (error) {
      console.error("Error fetching groups:", error)
    }
  }

  if (!currentUser?._id) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg mb-4">Please sign in to access messages</p>
          <Link href="/">
            <Button>Go Home</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Messages</h1>
          </div>
          {isAdmin && (
            <Button onClick={() => setShowGroupManagement(true)} className="gap-2">
              <Plus className="w-4 h-4" />
              Create Group
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-6 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 bg-white rounded-lg shadow">
            <div className="p-4 border-b">
              <h2 className="font-semibold">Chats</h2>
            </div>
            <div className="divide-y max-h-[calc(100vh-200px)] overflow-y-auto">
              {/* Admin Chat */}
              {!isAdmin && (
                <button
                  onClick={() => setSelectedChat({ type: "admin", id: "admin" })}
                  className={`w-full p-4 text-left hover:bg-gray-50 transition ${
                    selectedChat?.id === "admin" ? "bg-blue-50" : ""
                  }`}
                >
                  <p className="font-medium">Admin</p>
                  <p className="text-sm text-gray-500">Direct message</p>
                </button>
              )}

              {/* Groups */}
              {groups.map((group) => (
                <button
                  key={group._id}
                  onClick={() => setSelectedChat({ type: "group", id: group._id })}
                  className={`w-full p-4 text-left hover:bg-gray-50 transition ${
                    selectedChat?.id === group._id ? "bg-blue-50" : ""
                  }`}
                >
                  <p className="font-medium">{group.groupName}</p>
                  <p className="text-sm text-gray-500">{group.members.length} members</p>
                </button>
              ))}
            </div>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-5">
            {selectedChat ? (
              <ChatInterface currentUser={currentUser} selectedChat={selectedChat} isAdmin={isAdmin} />
            ) : (
              <div className="bg-white rounded-lg shadow h-full flex items-center justify-center">
                <p className="text-gray-500">Select a chat to start messaging</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Group Management Modal */}
      {showGroupManagement && (
        <GroupManagement
          currentUser={currentUser}
          onClose={() => {
            setShowGroupManagement(false)
            fetchGroups(currentUser._id)
          }}
        />
      )}
    </div>
  )
}
