"use client"

import { useState, useEffect } from "react"
import HeroSection from "@/components/hero-section"
import LatestFlats from "@/components/latest-flats"
import Footer from "@/components/footer"

export default function Home() {
  const [user, setUser] = useState(null)
  const [filters, setFilters] = useState(null)

  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        setUser(JSON.parse(storedUser))
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error)
      // If parsing fails, remove the corrupted item
      localStorage.removeItem("user")
      setUser(null)
    }
  }, [])

  const handleSearch = (searchFilters) => {
    setFilters(searchFilters)
  }

  return (
    <main className="min-h-screen">
      <HeroSection onSearch={handleSearch} />
      <LatestFlats user={user} filters={filters} />
      <Footer />
    </main>
  )
}
